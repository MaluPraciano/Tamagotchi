package view;

import java.util.Scanner;

import exceptions.OpcaoInvalidaException;
import exceptions.PetEstaComEnergiaBaixaException;
import exceptions.PetEstaLimpoException;
import exceptions.PetNaoEncontradoException;
import exceptions.PetSemFomeException;
import exceptions.PetSemSonoException;
import model.Pet;
import repository.PetRepository;
import service.PetService;

public class Menu {
	
	private PetRepository petRepository = new PetRepository();
	private PetService petService = new PetService(petRepository);

	public void start() {
		Scanner scanner = new Scanner(System.in);
		
        System.out.println();
        System.out.println("==============================");
        System.out.println("         TAMAGOTCHI           ");
        System.out.println("==============================");
        System.out.println("  1 - Iniciar jogo");
        System.out.println("  2 - Fechar jogo");
        System.out.println("==============================");
        System.out.print("Escolha uma opção: ");
        
        int opcao = scanner.nextInt();
       
        switch (opcao) {
        	case 1: {
        		this.game();
        		this.loop();
        		break;
        	}
        	case 2: {
        		System.out.println("FECHOU O JOGO");
        		break;
        	}
        }
        
        scanner.close();
	}
	
	public void game() {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println();
		System.out.println("==============================");
		System.out.println("       CRIE SEU BICHINHO      ");
		System.out.println("==============================");
		System.out.print("Digite o nome do bichinho: ");
		String nome = scanner.nextLine();
		
		
		String especie = null;
		while(especie == null) {
		System.out.println();
		System.out.println("==============================");
		System.out.println("       ESCOLHA A ESPÉCIE      ");
		System.out.println("==============================");
		System.out.println("  1 - Gato");
		System.out.println("  2 - Cachorro");
		System.out.println("  3 - Coelho");
		System.out.println("==============================");
		System.out.print("Escolha uma opção: ");
		
		int opcaoEspecie = scanner.nextInt();
		
		especie = switch (opcaoEspecie) {
		    case 1 -> especie = "Gato";
		    case 2 -> especie = "Cachorro";
		    case 3 -> especie = "Coelho";
	        default -> {
	            System.out.println("Opção inválida! Escolha de 1 a 3.");
	            yield null;
	        }
		};
	}
		
		this.petRepository.create(nome, especie);
		
		Pet pet = this.petRepository.find();
		System.out.println(pet);
		
        
	}
	
	public void loop() {
		Pet pet = petRepository.find();
		boolean jogando = true;
		
		while(jogando) {
		
		Scanner scanner = new Scanner(System.in);
		  	System.out.println();
		  	System.out.println("==============================");
		  	System.out.println("     STATUS DO BICHINHO       ");
		  	System.out.println("==============================");
		  	System.out.println("  Nome:       " + pet.getNome());
		  	System.out.println("  Espécie:    " + pet.getEspecie());
		  	System.out.println();
		  	System.out.println("  Fome:       " + pet.getSaciado());
		  	System.out.println("  Energia:    " + pet.getEnergia());
		  	System.out.println("  Felicidade: " + pet.getFelicidade());
		  	System.out.println("  Higiene:    " + pet.getHigiene());
		  	System.out.println("==============================");
	        System.out.println();
	        System.out.println("==============================");
	        System.out.println("       ESCOLHA UMA AÇÃO       ");
	        System.out.println("==============================");
	        System.out.println("  1 - Alimentar");
	        System.out.println("  2 - Brincar");
	        System.out.println("  3 - Dormir");
	        System.out.println("  4 - Dar banho");
	        System.out.println("  5 - Sair");
	        System.out.println("==============================");
	        System.out.print("Escolha uma opção: ");
	        
	        int opcaoAcao = scanner.nextInt();
	        
	        try{
	        	switch(opcaoAcao) {
	        case 1: {
	        		try {
	        			petService.alimentar();
	        		} catch(PetNaoEncontradoException e) {
	        			System.out.println(e.getMessage());
	        		} catch(PetSemFomeException e) {
	        			System.out.println(e.getMessage());
	        		}
	        		
	        		break;
	        	}
	       
	        case 2: {
	        		try {
	        			petService.brincar();
	        		} catch(PetEstaComEnergiaBaixaException e) {
	        			System.out.println(e.getMessage());
	        		} catch(PetNaoEncontradoException e) {
	        			System.out.println(e.getMessage());
	        		}
	        		
	        		break;
	        	}
	        case 3: {
	        		try {
	        			petService.dormir();
	        		} catch(PetSemSonoException e) {
	        			System.out.println(e.getMessage());
	        		} catch(PetNaoEncontradoException e) {
	        			System.out.println(e.getMessage());
	        		}
	        		break;
	        	}
	        case 4: {
	        		try {
	        			petService.darBanho();
	        		} catch(PetEstaLimpoException e) {
	        			System.out.println(e.getMessage());
	        		} catch(PetNaoEncontradoException e) {
	        			System.out.println(e.getMessage());
	        		}
	        		break;
	        	}
	        case 5: {
	        	System.out.println("Você saiu do jogo!");
	        	jogando = false;
	        	break;
	        	}
	        default:
	        	throw new OpcaoInvalidaException("Opção Inválida! Escolha de 1 até 5.");
	        }
		} catch (OpcaoInvalidaException e) {
			System.out.println(e.getMessage());
			}
		}
	}

}
