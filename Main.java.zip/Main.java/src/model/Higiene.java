package model;

public class Higiene extends Necessidade {

}
