package model;

public class Energia extends Necessidade {

}
