package model;

public class Felicidade extends Necessidade{

}
