package model;

public class Fome extends Necessidade{
	
}
